// Execute.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <sstream>
 
using namespace std;
 
void execute()
{
    string numbers;
    int hold = 1;
 
    for(;;)
    {
        cout << "Please enter the code: \n";
        getline(cin, numbers);
 
        if(numbers != "82634")
        {
            cout << "\nTry again.\n";
        } 
        else
        {
            cout << "Code accepted";
 
            break;
        }
    }
    
	cin.ignore();
}
 
int _tmain(int argc, _TCHAR* argv[])
{
    execute();
 
    return 0;
}