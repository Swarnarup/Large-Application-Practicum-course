
#ifndef BNK_ACCNT_H
#define BNK_ACCNT_H

#include <string>
#include vector



/**
  * class Bnk_Accnt
  * 
  */

class Bnk_Accnt
{
public:

  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  Bnk_Accnt ( );

  /**
   * Empty Destructor
   */
  virtual ~Bnk_Accnt ( );

  // Static Public attributes
  //  

  // Public attributes
  //  


  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  



  /**
   * @return TransacHist
   */
  TransacHist GetTransacHist ( )
  {
  }


  /**
   * @param  T1
   */
  void SetTransHist (TransacHist T1 )
  {
  }


  /**
   * @return Balance
   */
  Balance GetBalan ( )
  {
  }


  /**
   * @param  B1
   */
  void SetBalan (Balance B1 )
  {
  }

protected:

  // Static Protected attributes
  //  

  // Protected attributes
  //  

public:


  // Protected attribute accessor methods
  //  

protected:

public:


  // Protected attribute accessor methods
  //  

protected:


private:

  // Static Private attributes
  //  

  // Private attributes
  //  

public:


  // Private attribute accessor methods
  //  

private:

public:


  // Private attribute accessor methods
  //  

private:



};

#endif // BNK_ACCNT_H
