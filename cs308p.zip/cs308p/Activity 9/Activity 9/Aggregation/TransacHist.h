
#ifndef TRANSACHIST_H
#define TRANSACHIST_H

#include <string>
#include vector



/**
  * class TransacHist
  * 
  */

class TransacHist
{
public:

  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  TransacHist ( );

  /**
   * Empty Destructor
   */
  virtual ~TransacHist ( );

  // Static Public attributes
  //  

  // Public attributes
  //  


  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  



  /**
   * @param  Bnk1
   */
  void SetBnkAcc (Bnk_Accnt Bnk1 )
  {
  }


  /**
   * @return Bnk_Accnt
   */
  Bnk_Accnt GetBnkAccnt ( )
  {
  }

protected:

  // Static Protected attributes
  //  

  // Protected attributes
  //  

public:


  // Protected attribute accessor methods
  //  

protected:

public:


  // Protected attribute accessor methods
  //  

protected:


private:

  // Static Private attributes
  //  

  // Private attributes
  //  

public:


  // Private attribute accessor methods
  //  

private:

public:


  // Private attribute accessor methods
  //  

private:



};

#endif // TRANSACHIST_H
