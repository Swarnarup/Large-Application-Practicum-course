
#ifndef BALANCE_H
#define BALANCE_H

#include <string>
#include vector



/**
  * class Balance
  * 
  */

class Balance
{
public:

  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  Balance ( );

  /**
   * Empty Destructor
   */
  virtual ~Balance ( );

  // Static Public attributes
  //  

  // Public attributes
  //  


  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  



  /**
   * @param  Bnk1
   */
  void SetBnkAcc (Bnk_Accnt Bnk1 )
  {
  }


  /**
   * @return Bnk_Accnt
   */
  Bnk_Accnt GetBnkAcc ( )
  {
  }

protected:

  // Static Protected attributes
  //  

  // Protected attributes
  //  

public:


  // Protected attribute accessor methods
  //  

protected:

public:


  // Protected attribute accessor methods
  //  

protected:


private:

  // Static Private attributes
  //  

  // Private attributes
  //  

public:


  // Private attribute accessor methods
  //  

private:

public:


  // Private attribute accessor methods
  //  

private:



};

#endif // BALANCE_H
