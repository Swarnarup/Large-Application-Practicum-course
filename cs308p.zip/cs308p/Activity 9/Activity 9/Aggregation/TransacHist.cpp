#include "TransacHist.h"

// Constructors/Destructors
//  

TransacHist::TransacHist ( ) {
}

TransacHist::~TransacHist ( ) { }

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  


