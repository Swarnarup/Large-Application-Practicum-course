#include "AptBld.h"

// Constructors/Destructors
//  

AptBld::AptBld ( ) {
}

AptBld::~AptBld ( ) { }

//  
// Methods
//  


// Accessor methods
//  


/**
 * Add a Houses object to the m_housesVector List
 */
void AptBld::addHouses ( Tenant * add_object ) {
  m_housesVector.push_back(add_object);
}

/**
 * Remove a Houses object from m_housesVector List
 */
void AptBld::removeHouses ( Tenant * remove_object ) {
  int i, size = m_housesVector.size();
  for ( i = 0; i < size; ++i) {
  	Tenant * item = m_housesVector.at(i);
  	if(item == remove_object) {
  		vector<Tenant *>::iterator it = m_housesVector.begin() + i;
  		m_housesVector.erase(it);
  		return;
  	}
   }
}

/**
 * Get the list of Houses objects held by m_housesVector
 * @return vector<Tenant *> list of Houses objects held by m_housesVector
 */
vector<Tenant *> AptBld::getHousesList ( ) {
  return m_housesVector;
}

// Other methods
//  


