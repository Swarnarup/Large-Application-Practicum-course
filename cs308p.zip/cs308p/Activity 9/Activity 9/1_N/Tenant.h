
#ifndef TENANT_H
#define TENANT_H

#include <string>
#include vector

class AptBld;


/**
  * class Tenant
  * 
  */

class Tenant
{
public:

  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  Tenant ( );

  /**
   * Empty Destructor
   */
  virtual ~Tenant ( );

  // Static Public attributes
  //  

  // Public attributes
  //  


  AptBld * m_livesat;

  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  


  /**
   * Set the value of m_livesat
   * @param new_var the new value of m_livesat
   */
  void setLivesAt ( AptBld * new_var );

  /**
   * Get the value of m_livesat
   * @return the value of m_livesat
   */
  AptBld * getLivesAt ( );



  /**
   * @return AptBld
   */
  AptBld GetApt ( )
  {
  }


  /**
   * @param  A1
   */
  void SetApt (AptBld A1 )
  {
  }

protected:

  // Static Protected attributes
  //  

  // Protected attributes
  //  

public:


  // Protected attribute accessor methods
  //  

protected:

public:


  // Protected attribute accessor methods
  //  

protected:


private:

  // Static Private attributes
  //  

  // Private attributes
  //  

public:


  // Private attribute accessor methods
  //  

private:

public:


  // Private attribute accessor methods
  //  

private:



};

#endif // TENANT_H
