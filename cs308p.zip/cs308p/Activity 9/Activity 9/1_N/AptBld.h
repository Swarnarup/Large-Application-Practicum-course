
#ifndef APTBLD_H
#define APTBLD_H

#include <string>
#include vector

#include "Tenant.h"


/**
  * class AptBld
  * 
  */

class AptBld
{
public:

  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  AptBld ( );

  /**
   * Empty Destructor
   */
  virtual ~AptBld ( );

  // Static Public attributes
  //  

  // Public attributes
  //  


  vector<Tenant*> m_housesVector;

  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  


  /**
   * Add a Houses object to the m_housesVector List
   */
  void addHouses ( Tenant * add_object );

  /**
   * Remove a Houses object from m_housesVector List
   */
  void removeHouses ( Tenant * remove_object );

  /**
   * Get the list of Houses objects held by m_housesVector
   * @return vector<Tenant *> list of Houses objects held by m_housesVector
   */
  vector<Tenant *> getHousesList ( );


  /**
   * @return Tenant
   */
  Tenant GetTenant ( )
  {
  }


  /**
   * @param  R1
   */
  void SetTenant (Tenant R1 )
  {
  }

protected:

  // Static Protected attributes
  //  

  // Protected attributes
  //  

public:


  // Protected attribute accessor methods
  //  

protected:

public:


  // Protected attribute accessor methods
  //  

protected:


private:

  // Static Private attributes
  //  

  // Private attributes
  //  

public:


  // Private attribute accessor methods
  //  

private:

public:


  // Private attribute accessor methods
  //  

private:



};

#endif // APTBLD_H
