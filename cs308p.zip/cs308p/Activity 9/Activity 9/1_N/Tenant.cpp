#include "Tenant.h"

// Constructors/Destructors
//  

Tenant::Tenant ( ) {
}

Tenant::~Tenant ( ) { }

//  
// Methods
//  


// Accessor methods
//  


/**
 * Set the value of m_livesat
 * @param new_var the new value of m_livesat
 */
void Tenant::setLivesAt ( AptBld * new_var ) {
  m_livesat = new_var;
}

/**
 * Get the value of m_livesat
 * @return the value of m_livesat
 */
AptBld * Tenant::getLivesAt ( ) {
  return m_livesat;
}

// Other methods
//  


