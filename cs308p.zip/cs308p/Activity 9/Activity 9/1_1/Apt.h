
#ifndef APT_H
#define APT_H

#include <string>
#include vector

#include "Renter.h"


/**
  * class Apt
  * 
  */

class Apt
{
public:

  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  Apt ( );

  /**
   * Empty Destructor
   */
  virtual ~Apt ( );

  // Static Public attributes
  //  

  // Public attributes
  //  


  Renter * m_tenant;

  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  


  /**
   * Set the value of m_tenant
   * @param new_var the new value of m_tenant
   */
  void setTenant ( Renter * new_var );

  /**
   * Get the value of m_tenant
   * @return the value of m_tenant
   */
  Renter * getTenant ( );



  /**
   * @return Renter
   */
  Renter GetRenter ( )
  {
  }


  /**
   * @param  R1
   */
  void SetRenter (Renter R1 )
  {
  }

protected:

  // Static Protected attributes
  //  

  // Protected attributes
  //  

public:


  // Protected attribute accessor methods
  //  

protected:

public:


  // Protected attribute accessor methods
  //  

protected:


private:

  // Static Private attributes
  //  

  // Private attributes
  //  

public:


  // Private attribute accessor methods
  //  

private:

public:


  // Private attribute accessor methods
  //  

private:



};

#endif // APT_H
