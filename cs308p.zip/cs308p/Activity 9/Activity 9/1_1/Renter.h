
#ifndef RENTER_H
#define RENTER_H

#include <string>
#include vector

class Apt;


/**
  * class Renter
  * 
  */

class Renter
{
public:

  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  Renter ( );

  /**
   * Empty Destructor
   */
  virtual ~Renter ( );

  // Static Public attributes
  //  

  // Public attributes
  //  


  Apt * m_dwell;

  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  


  /**
   * Set the value of m_dwell
   * @param new_var the new value of m_dwell
   */
  void setDwell ( Apt * new_var );

  /**
   * Get the value of m_dwell
   * @return the value of m_dwell
   */
  Apt * getDwell ( );



  /**
   * @return Apt
   */
  Apt GetApt ( )
  {
  }


  /**
   * @param  A1
   */
  void SetApt (Apt A1 )
  {
  }

protected:

  // Static Protected attributes
  //  

  // Protected attributes
  //  

public:


  // Protected attribute accessor methods
  //  

protected:

public:


  // Protected attribute accessor methods
  //  

protected:


private:

  // Static Private attributes
  //  

  // Private attributes
  //  

public:


  // Private attribute accessor methods
  //  

private:

public:


  // Private attribute accessor methods
  //  

private:



};

#endif // RENTER_H
