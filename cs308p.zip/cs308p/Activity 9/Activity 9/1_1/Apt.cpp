#include "Apt.h"

// Constructors/Destructors
//  

Apt::Apt ( ) {
}

Apt::~Apt ( ) { }

//  
// Methods
//  


// Accessor methods
//  


/**
 * Set the value of m_tenant
 * @param new_var the new value of m_tenant
 */
void Apt::setTenant ( Renter * new_var ) {
  m_tenant = new_var;
}

/**
 * Get the value of m_tenant
 * @return the value of m_tenant
 */
Renter * Apt::getTenant ( ) {
  return m_tenant;
}

// Other methods
//  


