#include "Renter.h"

// Constructors/Destructors
//  

Renter::Renter ( ) {
}

Renter::~Renter ( ) { }

//  
// Methods
//  


// Accessor methods
//  


/**
 * Set the value of m_dwell
 * @param new_var the new value of m_dwell
 */
void Renter::setDwell ( Apt * new_var ) {
  m_dwell = new_var;
}

/**
 * Get the value of m_dwell
 * @return the value of m_dwell
 */
Apt * Renter::getDwell ( ) {
  return m_dwell;
}

// Other methods
//  


