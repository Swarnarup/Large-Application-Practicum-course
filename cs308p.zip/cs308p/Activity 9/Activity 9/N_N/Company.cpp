#include "Company.h"

// Constructors/Destructors
//  

Company::Company ( ) {
}

Company::~Company ( ) { }

//  
// Methods
//  


// Accessor methods
//  


/**
 * Add a Employees object to the m_employeesVector List
 */
void Company::addEmployees ( Contractor * add_object ) {
  m_employeesVector.push_back(add_object);
}

/**
 * Remove a Employees object from m_employeesVector List
 */
void Company::removeEmployees ( Contractor * remove_object ) {
  int i, size = m_employeesVector.size();
  for ( i = 0; i < size; ++i) {
  	Contractor * item = m_employeesVector.at(i);
  	if(item == remove_object) {
  		vector<Contractor *>::iterator it = m_employeesVector.begin() + i;
  		m_employeesVector.erase(it);
  		return;
  	}
   }
}

/**
 * Get the list of Employees objects held by m_employeesVector
 * @return vector<Contractor *> list of Employees objects held by m_employeesVector
 */
vector<Contractor *> Company::getEmployeesList ( ) {
  return m_employeesVector;
}

// Other methods
//  


