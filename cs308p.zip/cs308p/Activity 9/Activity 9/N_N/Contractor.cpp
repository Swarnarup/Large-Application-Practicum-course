#include "Contractor.h"

// Constructors/Destructors
//  

Contractor::Contractor ( ) {
}

Contractor::~Contractor ( ) { }

//  
// Methods
//  


// Accessor methods
//  


/**
 * Add a WorksFor object to the m_worksforVector List
 */
void Contractor::addWorksFor ( Company * add_object ) {
  m_worksforVector.push_back(add_object);
}

/**
 * Remove a WorksFor object from m_worksforVector List
 */
void Contractor::removeWorksFor ( Company * remove_object ) {
  int i, size = m_worksforVector.size();
  for ( i = 0; i < size; ++i) {
  	Company * item = m_worksforVector.at(i);
  	if(item == remove_object) {
  		vector<Company *>::iterator it = m_worksforVector.begin() + i;
  		m_worksforVector.erase(it);
  		return;
  	}
   }
}

/**
 * Get the list of WorksFor objects held by m_worksforVector
 * @return vector<Company *> list of WorksFor objects held by m_worksforVector
 */
vector<Company *> Contractor::getWorksForList ( ) {
  return m_worksforVector;
}

// Other methods
//  


