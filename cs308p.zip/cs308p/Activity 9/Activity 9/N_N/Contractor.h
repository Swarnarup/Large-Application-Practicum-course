
#ifndef CONTRACTOR_H
#define CONTRACTOR_H

#include <string>
#include vector

#include "Company.h"


/**
  * class Contractor
  * 
  */

class Contractor
{
public:

  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  Contractor ( );

  /**
   * Empty Destructor
   */
  virtual ~Contractor ( );

  // Static Public attributes
  //  

  // Public attributes
  //  


  vector<Company*> m_worksforVector;

  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  


  /**
   * Add a WorksFor object to the m_worksforVector List
   */
  void addWorksFor ( Company * add_object );

  /**
   * Remove a WorksFor object from m_worksforVector List
   */
  void removeWorksFor ( Company * remove_object );

  /**
   * Get the list of WorksFor objects held by m_worksforVector
   * @return vector<Company *> list of WorksFor objects held by m_worksforVector
   */
  vector<Company *> getWorksForList ( );


  /**
   * @return Company
   */
  Company GetCompany ( )
  {
  }


  /**
   * @param  R1
   */
  void SetCompany (Company R1 )
  {
  }

protected:

  // Static Protected attributes
  //  

  // Protected attributes
  //  

public:


  // Protected attribute accessor methods
  //  

protected:

public:


  // Protected attribute accessor methods
  //  

protected:


private:

  // Static Private attributes
  //  

  // Private attributes
  //  

public:


  // Private attribute accessor methods
  //  

private:

public:


  // Private attribute accessor methods
  //  

private:



};

#endif // CONTRACTOR_H
