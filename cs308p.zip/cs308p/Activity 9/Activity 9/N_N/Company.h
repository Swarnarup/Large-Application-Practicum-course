
#ifndef COMPANY_H
#define COMPANY_H

#include <string>
#include vector

class Contractor;


/**
  * class Company
  * 
  */

class Company
{
public:

  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  Company ( );

  /**
   * Empty Destructor
   */
  virtual ~Company ( );

  // Static Public attributes
  //  

  // Public attributes
  //  


  vector<Contractor*> m_employeesVector;

  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  


  /**
   * Add a Employees object to the m_employeesVector List
   */
  void addEmployees ( Contractor * add_object );

  /**
   * Remove a Employees object from m_employeesVector List
   */
  void removeEmployees ( Contractor * remove_object );

  /**
   * Get the list of Employees objects held by m_employeesVector
   * @return vector<Contractor *> list of Employees objects held by m_employeesVector
   */
  vector<Contractor *> getEmployeesList ( );


  /**
   * @return Contractor
   */
  Contractor GetContractor ( )
  {
  }


  /**
   * @param  A1
   */
  void SetContractor (Contractor A1 )
  {
  }

protected:

  // Static Protected attributes
  //  

  // Protected attributes
  //  

public:


  // Protected attribute accessor methods
  //  

protected:

public:


  // Protected attribute accessor methods
  //  

protected:


private:

  // Static Private attributes
  //  

  // Private attributes
  //  

public:


  // Private attribute accessor methods
  //  

private:

public:


  // Private attribute accessor methods
  //  

private:



};

#endif // COMPANY_H
