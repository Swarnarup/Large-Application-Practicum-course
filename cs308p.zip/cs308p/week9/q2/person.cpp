#include "person.h"

// Constructors/Destructors
//  

person::person()
{
  initAttributes();
}

person::~person()
{
}

//  
// Methods
//  


// Accessor methods
//  


/**
 * Add a Have object to the m_haveVector List
 */
void person::addHave (bank_account * add_object) {
  m_haveVector.push_back(add_object);
}

/**
 * Remove a Have object from m_haveVector List
 */
void person::removeHave (bank_account * remove_object) {
  int i, size = m_haveVector.size();
  for (i = 0; i < size; ++i) {
  	bank_account * item = m_haveVector.at(i);
  	if(item == remove_object) {
  		std::vector<bank_account *>::iterator it = m_haveVector.begin() + i;
  		m_haveVector.erase(it);
  		return;
  	}
   }
}

/**
 * Get the list of Have objects held by m_haveVector
 * @return std::vector<bank_account *> list of Have objects held by m_haveVector
 */
std::vector<bank_account *> person::getHaveList() {
  return m_haveVector;
}

// Other methods
//  

void person::initAttributes()
{
}

