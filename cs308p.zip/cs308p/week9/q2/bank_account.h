
#ifndef BANK_ACCOUNT_H
#define BANK_ACCOUNT_H

#include <vector>

class person;


/**
  * class bank_account
  * 
  */

class bank_account
{
public:
  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  bank_account();

  /**
   * Empty Destructor
   */
  virtual ~bank_account();

  // Static Public attributes
  //  

  // Public attributes
  //  


  person * m_owned_by;

  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  


  /**
   * Set the value of m_owned_by
   * @param value the new value of m_owned_by
   */
  void setOwned_by(person * value);

  /**
   * Get the value of m_owned_by
   * @return the value of m_owned_by
   */
  person * getOwned_by();

protected:
  // Static Protected attributes
  //  

  // Protected attributes
  //  


  // Protected attribute accessor methods
  //  


  // Protected attribute accessor methods
  //

private:
  // Static Private attributes
  //  

  // Private attributes
  //  

  int account_number;
  int balance;

  // Private attribute accessor methods
  //  


  // Private attribute accessor methods
  //  


  /**
   * Set the value of account_number
   * @param value the new value of account_number
   */
  void setAccount_number(int value)
  {
    account_number = value;
  }

  /**
   * Get the value of account_number
   * @return the value of account_number
   */
  int getAccount_number()
  {
    return account_number;
  }

  /**
   * Set the value of balance
   * @param value the new value of balance
   */
  void setBalance(int value)
  {
    balance = value;
  }

  /**
   * Get the value of balance
   * @return the value of balance
   */
  int getBalance()
  {
    return balance;
  }

  void initAttributes();

};

#endif // BANK_ACCOUNT_H
