#include "person.h"

// Constructors/Destructors
//  

bank_account::bank_account()
{
  initAttributes();
}

bank_account::~bank_account()
{
}

//  
// Methods
//  


// Accessor methods
//  


/**
 * Set the value of m_owned_by
 * @param value the new value of m_owned_by
 */
void bank_account::setOwned_by(person * value)
{
  m_owned_by = value;
}

/**
 * Get the value of m_owned_by
 * @return the value of m_owned_by
 */
person * bank_account::getOwned_by()
{
  return m_owned_by;
}

// Other methods
//  

void bank_account::initAttributes()
{
  m_owned_by = new person();
}

