
#ifndef PERSON_H
#define PERSON_H

#include <vector>

#include "bank_account.h"


/**
  * class person
  * 
  */

class person
{
public:
  // Constructors/Destructors
  //  


  /**
   * Empty Constructor
   */
  person();

  /**
   * Empty Destructor
   */
  virtual ~person();

  // Static Public attributes
  //  

  // Public attributes
  //  

  int account_number;

  std::vector<bank_account*> m_haveVector;

  // Public attribute accessor methods
  //  


  // Public attribute accessor methods
  //  


  /**
   * Set the value of account_number
   * @param value the new value of account_number
   */
  void setAccount_number(int value)
  {
    account_number = value;
  }

  /**
   * Get the value of account_number
   * @return the value of account_number
   */
  int getAccount_number()
  {
    return account_number;
  }

  /**
   * Add a Have object to the m_haveVector List
   */
  void addHave (bank_account * add_object);

  /**
   * Remove a Have object from m_haveVector List
   */
  void removeHave (bank_account * remove_object);

  /**
   * Get the list of Have objects held by m_haveVector
   * @return std::vector<bank_account *> list of Have objects held by m_haveVector
   */
  std::vector<bank_account *> getHaveList();


  /**
   * @return int
   */
  int query_balance() const
  {
  }


  /**
   * @return bool
   */
  bool withdraw_cash() const
  {
  }


  /**
   * @return bool
   */
  bool deposite_cash()
  {
  }

protected:
  // Static Protected attributes
  //  

  // Protected attributes
  //  


  // Protected attribute accessor methods
  //  


  // Protected attribute accessor methods
  //

private:
  // Static Private attributes
  //  

  // Private attributes
  //  

  char password;

  // Private attribute accessor methods
  //  


  // Private attribute accessor methods
  //  


  /**
   * Set the value of password
   * @param value the new value of password
   */
  void setPassword(char value)
  {
    password = value;
  }

  /**
   * Get the value of password
   * @return the value of password
   */
  char getPassword()
  {
    return password;
  }

  void initAttributes();

};

#endif // PERSON_H
