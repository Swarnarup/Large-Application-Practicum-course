package testcase;

import static org.junit.Assert.*;
import org.junit.*;
import logic.*;

public class TestCase {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		//write a System.out.println("...") statement to check when this executes
//		Calculation clc=new Calculation();
//		System.out.println(clc.reverseWord("i am    Swarna"));
		
//		System.out.println(" debug- Before class");
		
	}
	@Before
	public void setUp() throws Exception {
		//write a System.out.println("...") statement to check when this executes
//		System.out.println(" debug- Before");
	}

	@Test
	public void testFindMax(){
	//write asserts to test the functionality of findMax method
	//does this method fail for negative integers?
		
		Calculation clc=new Calculation();

		assertEquals("testing for findmax ",10,clc.findMax(new int[] {1,2,10,6}));
		assertEquals("testing for findmax ",-2,clc.findMax(new int[] {-11,-2,-10}));
		assertEquals("testing for findmax ",2,clc.findMax(new int[] {-1,2,-10}));
		assertEquals("testing for findmax ",11,clc.findMax(new int[] {11,-2,-1}));
		
		assertEquals("testing for findmax ","nurav ttud",clc.reverseWord("varun dutt"));
		
		assertEquals("testing for findmax ","i ma anrawS",clc.reverseWord("i am Swarna"));
		
		assertEquals("testing for findmax ",125,clc.cube(5));
		
	}
	
//	@Test
//	public void test1() {
//		System.out.println(" debug- test");
//	}
//	@Test
//	public void test2() {
//		System.out.println(" debug- test");
//	}
//	@Test
//	public void test3() {
//		System.out.println(" debug- test");
//	}
//	@Test
//	public void test4() {
//		System.out.println(" debug- test");
//	}
	
	
	
	//write a test case to test the functionality of reverseWord method
	//does this assert fails while reversing words?	
	
	//write a test case to test the functionality of cube method	
	//does this assert fails while calling cube?	
	
	@After
	public void tearDown() throws Exception {
		//write a System.out.println("...") statement to check when this executes
//		System.out.println(" debug- After");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		//write a System.out.println("...") statement to check when this executes
//		System.out.println(" debug- After class");
	}

}
