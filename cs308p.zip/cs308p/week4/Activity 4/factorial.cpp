#include <iostream>
#include <cstdio>

using namespace std;

int factorial(int num)
{
	int ans=1;
	for(int i=1; i<=num; i++)
		ans = ans * num;

	return ans;
}


int main()
{
	int var = 5;
	int fact5 = factorial(var);
	cout<<"Factorial of "<<var<<": "<<fact5<<"\n";

	return 0;
}