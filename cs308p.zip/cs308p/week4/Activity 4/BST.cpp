#ifndef BST_H
#define BST_H

struct Node
{
	int key;
	Node* left;
	Node* right;
};

class BST
{
private:
	Node* root;
	int count;
	void inorder(Node* r);
	void preorder(Node* r);
	void postorder(Node* r);

public:
	BST();
	bool insert(int key);
	bool search(int key);
	bool remove(int key);
	void inorder();
	void preorder();
	void postorder();
	int size();
};

