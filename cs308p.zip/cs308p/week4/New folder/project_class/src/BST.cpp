#ifndef BST_H
#define BST_H

/*
Constructor: Node
constructs a node in bst
*/

struct Node
{
	int key;
	Node* left;
	Node* right;
};

/*

Class: BST

this class is to automate the linking process of a node to it's left child and right child node
*/

class BST
{
private:
	Node* root;
	int count;

	/*
	Function: inorder
	stores nodes in inorder traversal
	*/
	void inorder(Node* r);
	/*
	Function: preorder
	stores nodes in preorder traversal
	*/
	void preorder(Node* r);
	/*
	Function: postorder
	stores nodes in postorder traversal
	*/
	void postorder(Node* r);

public:

	/*
	Constructor: BST
	initializes the bst object

	
	inorder - the function to help inorder traversal.
	preorder - the function to help preorder traversal.
	postorder - the function to help postorder traversal.


	(see Asset/bst.gif)


	See Also:
		<inorder> ,
		<preorder> ,
		<postorder>



	website link for more information 
	<https://www.geeksforgeeks.org/binary-search-tree-data-structure/>
	*/
	BST();
	bool insert(int key);
	bool search(int key);
	bool remove(int key);
	void inorder();
	void preorder();
	void postorder();
	int size();
};

