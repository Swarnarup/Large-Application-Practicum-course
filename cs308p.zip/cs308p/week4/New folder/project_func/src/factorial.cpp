#include <iostream>
#include <cstdio>

using namespace std;

/*

Function: factorial

it takes an integer and returns it's factorial.

*/

int factorial(int num)
{
	int ans=1;
	for(int i=1; i<=num; i++)
		ans = ans * num;

	return ans;
}

/*
Function: main

It takes no argument but returns the output of factorial(5)

See Also: 
	<factorial>

*/

int main()
{
	int var = 5;
	int fact5 = factorial(var);
	cout<<"Factorial of "<<var<<": "<<fact5<<"\n";

	return 0;
}