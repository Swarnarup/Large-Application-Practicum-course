void print_hello();
int factorial(int n);
int gcd(int a,int b);
int gcd_rec(int a,int b);