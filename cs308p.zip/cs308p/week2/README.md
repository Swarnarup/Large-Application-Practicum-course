# This programme takes an integer input and outputs the factorial of the input
### formula for factorial n! = n*(n-1)*(n-2)...2*1
### if n=0 , n! = 1
## PrintHello() function in the hello.cpp file prints the string "Hello world"
