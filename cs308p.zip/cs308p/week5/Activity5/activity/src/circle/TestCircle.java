




package circle;
import junit.framework.*;

import org.junit.Test;
//import 

public class TestCircle extends TestCase
{

	@Test
	public void test_FormattedArea() {
		
		Circle circle = new Circle(2.0, 0);
		String formattedArea = circle.getFormattedArea();
		assertEquals("Formatted area should match", "12.566", formattedArea);
	}

 @Test
 public void test_FormattedRadius() {
	 
	 Circle circle = new Circle(0, 12.566);
	 String formattedRadius = circle.getFormattedRadius();
	 assertEquals("Formatted radius should be = ", "2.0", formattedRadius);
 }
 
 
 @Test
 public void test_compute_radius() {

	 double expectedradius = 1.0;
     double area = 3.142;
     double computedradius = Circle.computeRadius(area);
     assertEquals("Computed area should be = ", expectedradius, computedradius, 0.01);
	 

 }
 
 
 @Test
 public void test_compute_area(){

	 double radius = 1.0;
     double expectedArea = 3.14;
     double computedArea = Circle.computeArea(radius);
     assertEquals("Computed area should be = ", expectedArea, computedArea, 0.01);
	 

 }
 


}








