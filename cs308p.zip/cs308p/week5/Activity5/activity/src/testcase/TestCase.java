package testcase;

import static org.junit.Assert.*;
import org.junit.*;

import circle.Circle;
import logic.*;

public class TestCase {
	
	String str1 = "test";
	String str2 = "test";
	
	@Test
	public void tts() {
	
		
		if (str1 != str2) {
			System.out.println("nhgfjg hg");}
		assertEquals("is same",str1, str2);
	
	}

//	@BeforeClass
//	public static void setUpBeforeClass() throws Exception {
//		//write a System.out.println("...") statement to check when this executes
//		Calculation clc=new Calculation();
//		System.out.println(clc.cube(5));
//	}
//	@Before
//	public void setUp() throws Exception {
//		//write a System.out.println("...") statement to check when this executes
//	}
//
//	@Test
//	public void testFindMax(){
//	//write asserts to test the functionality of findMax method
//	//does this method fail for negative integers?
//	}
//	
//	//write a test case to test the functionality of reverseWord method
//	//does this assert fails while reversing words?	
//	
//	//write a test case to test the functionality of cube method	
//	//does this assert fails while calling cube?	
//	
//	@After
//	public void tearDown() throws Exception {
//		//write a System.out.println("...") statement to check when this executes
//	}
//
//	@AfterClass
//	public static void tearDownAfterClass() throws Exception {
//		//write a System.out.println("...") statement to check when this executes
//	}

}
