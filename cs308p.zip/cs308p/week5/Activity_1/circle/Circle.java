package circle;
import java.text.DecimalFormat;
/**
  * class for circle computations
  */
public class Circle
{
    private double radius;
    private double area;


    /* construct a circle.  
     * @param radius the radius of the circle if known, otherwise 0
     * @param area the area of the circle if known, otherwise 0
     */
    public Circle(double radius, double area)
    {
        if (radius == 0)
        {
           this.area = area;
           this.radius =  computeRadius (area);
           
        }
        else if (area == 0)
        {
            this.radius = radius;
            this.area = computeArea ( radius);
        }
    }

    public static double computeRadius (double area)
    {
        if (area >= 0.0)
        {
            return Math.sqrt (area / Math.PI);        
        }
        else
        {
            return 0;
        }

    }

    public static double computeArea (double radius)
    {
        return  Math.PI * radius * radius;        
    }

  // Gets a double value from a text field.  If the text in the field
  // is a legal integer, converts and returns it as a double.  If not,
  // pops up an error message and returns zero instead.  Blank fields
  // are interpreted as zeros.
  // Parameters:
  //   field: the field containing the value
  //   fieldName: the name of the field, for error messages
  public static double toDouble(String field) 
  {
    // the contents of the text field as a string, minus any leading
    // or trailing blanks
    String fieldContents = field.trim();
    if (fieldContents.length() == 0)
      return 0;
      
    // Calling Double.parseDouble will raise a NumberFormatException if
    // the parameter is not in double format.  We will catch that
    // exception and report an error, instead of letting the program
    // end.
    try 
    {
      return Double.parseDouble(fieldContents);
    }
    catch (NumberFormatException ex) { return 0; }
  }

  // Formatting pattern for displaying the area with a limited
  // number of decimal digits
  private DecimalFormat fixedFormat = new DecimalFormat("0.0##");
  // Another pattern for large numbers, using scientific notation
  private DecimalFormat sciFormat = new DecimalFormat("0.0##E0");

    public String getFormattedRadius()
    {
            return fixedFormat.format(radius);
    }

      // convert double to String, using formatting pattern to
      // round to 3 digits.  If the result won't fit into the area
      // field, it's because the number is large and there are 
      // too many digits before the decimal point.  Use the alternate
      // pattern with scientific notation.
    public String getFormattedArea()
    {
        String areaString = fixedFormat.format(area);
        if (areaString.length() > 10)
        {
          	areaString = sciFormat.format(area);
        }
        return areaString;
    }

    public String toString()
    {
        return " " + radius + " : " + area;
    }
}

