package circle;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


/************************************************************************
 * Convert circle dimensions between radius and area. 
 * A demo program to serve as an example for class exercise.
 ***********************************************************************/
public class CircleConverter extends JFrame  
{
  private JTextField radiusField;  // entry field for radius
  private JTextField areaField;    // entry field for area
  private JButton clearButton;     // clear the fields button
  private JButton exitButton;	   // exit button
  
  private Container contents;
  
  // Constructor and GUI widget layout
  public CircleConverter() 
  {
    setTitle("Circle Converter");
    
    contents = getContentPane(); 
    contents.setLayout(new FlowLayout());      
    
    JPanel row1 = new JPanel();
    JLabel radiusLabel = new JLabel("radius: ");
    row1.add(radiusLabel);

    radiusField = new JTextField(4);
    row1.add(radiusField);
    contents.add(row1);
   
    JPanel row2 = new JPanel();
    JLabel areaLabel = new JLabel("area: ");
    row2.add(areaLabel);

    areaField = new JTextField(8);
    row2.add(areaField);
    contents.add(row2);

    clearButton = new JButton ("Clear");
    clearButton.setMnemonic(KeyEvent.VK_C);
    contents.add(clearButton);
    
    exitButton = new JButton ("Exit");
    exitButton.setMnemonic(KeyEvent.VK_X);
    contents.add(exitButton);

    TextFieldHandler handler = new TextFieldHandler();
    areaField.addActionListener(handler);
    radiusField.addActionListener(handler);
    ButtonHandler bhandler = new ButtonHandler();
    clearButton.addActionListener(bhandler);
    exitButton.addActionListener(bhandler);

    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setSize( 200, 150 );

    setVisible(true);
  } // end constructor
  
  
  public static void main(String args[]) {
    JFrame window = new CircleConverter();
  }

    /** An inner class for handling compute requests  */
    private class TextFieldHandler implements ActionListener 
    {

  
  // Handle the user's action. 
  //    Called when user presses Enter in either of the text fields
  public void actionPerformed(ActionEvent e) 
  {
    // Did user enter a radius?
    if ( e.getSource() == radiusField )
    {
	    double radius = Circle.toDouble(radiusField.getText());
	    Circle aCircle = new Circle(radius,0);
        areaField.setText(aCircle.getFormattedArea());
    }
    // Did user enter an area?
    else if (e.getSource() == areaField )
    {
	    double area = Circle.toDouble(areaField.getText());
	    Circle aCircle = new Circle(0,area);
        radiusField.setText(aCircle.getFormattedRadius());
    }

  } // end actionPerformed
} // end inner class

    /** An inner class for button actions   */
    private class ButtonHandler implements ActionListener 
    {
  // Handle the user's action. 
  //    Called when the clear or exit buttons are pressed
  public void actionPerformed(ActionEvent e) 
  {
    if (e.getSource() == clearButton )
    {
		radiusField.setText("");
		areaField.setText("");
        radiusField.requestFocus(); 
    }
    else if (e.getSource() == exitButton )
    {
	    dispose();
    }
   } // end actionPerformed
  } // end inner class
}
