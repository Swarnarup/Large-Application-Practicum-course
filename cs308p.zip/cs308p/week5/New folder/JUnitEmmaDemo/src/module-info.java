/**
 * 
 */
/**
 * 
 */
module JUnitEmmaDemo {
	requires java.desktop;
	requires junit;
	
}